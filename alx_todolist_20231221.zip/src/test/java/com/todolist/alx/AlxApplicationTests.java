package com.todolist.alx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlxApplicationTests {

	@Test
	void contextLoads() {
	}

}
