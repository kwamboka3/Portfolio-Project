package com.todolist.alx.service;

import com.todolist.alx.dto.TaskDto;
import com.todolist.alx.entity.Task;
import com.todolist.alx.mapper.TaskMapper;
import com.todolist.alx.repository.TaskRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@Transactional
public class TaskService {
    private final TaskRepository repository;
    private final TaskMapper taskMapper;

    public TaskService(TaskRepository repository, TaskMapper taskMapper) {
        this.repository = repository;
        this.taskMapper = taskMapper;
    }

    public TaskDto save(TaskDto taskDto) {
        Task entity = taskMapper.toEntity(taskDto);
        return taskMapper.toDto(repository.save(entity));
    }

    public void deleteById(Integer id) {
        repository.deleteById(id);
    }

    public TaskDto findById(Integer id) {
        return taskMapper
                .toDto(repository.findById(id).orElse(new Task()));
    }

    public Page<TaskDto> findByCondition(TaskDto taskDto, Pageable pageable) {
        Page<Task> entityPage = repository.findAll(pageable);
        List<Task> entities = entityPage.getContent();
        return new PageImpl<>(taskMapper.toDto(entities), pageable, entityPage.getTotalElements());
    }

    public TaskDto update(TaskDto taskDto, Integer id) {
        TaskDto data = findById(id);

        // Merge changes from taskDto into the existing data object
        if (taskDto.getStatus() != null) {
            data.setStatus(taskDto.getStatus());
        }
        // Add other fields to update similarly if needed

        Task entity = taskMapper.toEntity(data); // Convert updated data back to entity if needed
        // Save the updated entity (assuming save method persists changes)
        return save(taskMapper.toDto(entity));
    }

}