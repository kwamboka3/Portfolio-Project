package com.todolist.alx.controller;

import com.todolist.alx.dto.TaskDto;
import com.todolist.alx.service.TaskService;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.ResourceAccessException;

import java.util.Optional;

@RequestMapping("/api/task")
@RestController
@Slf4j
@Api("task")
public class TaskController {
    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody @Validated TaskDto taskDto) {
        taskDto.setStatus(0);
        taskService.save(taskDto);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<TaskDto> findById(@PathVariable("id") Integer id) {
        TaskDto task = taskService.findById(id);
        return ResponseEntity.ok(task);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Integer id) {
        Optional.ofNullable(taskService.findById(id)).orElseThrow(() -> {
            log.error("Unable to delete non-existent data！");
            return new ResourceAccessException("Not Found");
        });
        taskService.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/page-query")
    public ResponseEntity<Page<TaskDto>> pageQuery(TaskDto taskDto,
            @PageableDefault(sort = "createAt", direction = Sort.Direction.DESC) Pageable pageable) {
        Page<TaskDto> taskPage = taskService.findByCondition(taskDto, pageable);
        return ResponseEntity.ok(taskPage);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody TaskDto taskDto, @PathVariable("id") Integer id) {
        taskService.update(taskDto, id);
        return ResponseEntity.ok().build();
    }
}