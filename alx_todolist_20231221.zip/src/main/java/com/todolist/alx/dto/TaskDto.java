package com.todolist.alx.dto;

import java.time.LocalDate;

import com.todolist.alx.annotation.CheckDate;

import io.swagger.annotations.ApiModel;

@ApiModel()
public class TaskDto extends AbstractDto<Integer> {
    private Integer id;
    private String description;
    @CheckDate
    private LocalDate dueDate;
    private Integer complete;
    private String title;

    public TaskDto() {
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return this.id;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDueDate(java.time.LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public java.time.LocalDate getDueDate() {
        return this.dueDate;
    }

    public void setStatus(Integer complete) {
        this.complete = complete;
    }

    public Integer getStatus() {
        return this.complete;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return this.title;
    }
}