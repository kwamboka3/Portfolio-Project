package com.todolist.alx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlxApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlxApplication.class, args);
	}

}
