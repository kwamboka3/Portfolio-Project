package com.todolist.alx.mapper;

import org.mapstruct.Mapper;

import com.todolist.alx.dto.TaskDto;
import com.todolist.alx.entity.Task;

@Mapper(componentModel = "spring")
public interface TaskMapper extends EntityMapper<TaskDto, Task> {
}